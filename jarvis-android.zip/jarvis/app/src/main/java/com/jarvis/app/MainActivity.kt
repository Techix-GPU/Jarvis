package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("j", 0)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        fun field(hint: String, key: String) = EditText(this).apply {
            this.hint = hint; setText(p.getString(key, "")); col.addView(this)
        }
        val nm = field("Your name", "name").apply { if (text.isBlank()) setText("Shiba") }
        val pv = field("Picovoice AccessKey", "pv")
        val el = field("ElevenLabs API key (optional)", "eleven")
        val vid = field("ElevenLabs male voice ID (blank = Adam)", "voice")
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() }; col.addView(this) }

        btn("1. Grant permissions") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS,
                "android.permission.POST_NOTIFICATIONS"), 1)
        }
        btn("2. Enable Jarvis accessibility") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName")))
        }
        btn("4. Start Jarvis") {
            p.edit().putString("name", nm.text.toString().trim()).putString("pv", pv.text.toString().trim())
                .putString("eleven", el.text.toString().trim()).putString("voice", vid.text.toString().trim()).apply()
            if (pv.text.isBlank()) {
                Toast.makeText(this, "Paste your Picovoice AccessKey first", Toast.LENGTH_LONG).show()
            } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Tap 1. Grant permissions first and allow the microphone", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, JarvisService::class.java))
            }
        }
        btn("Copy my feature requests (to send to Claude)") {
            val t = File(filesDir, "requests.txt").takeIf { it.exists() }?.readText().orEmpty().ifBlank { "(none yet)" }
            getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("requests", t))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }
        btn("Stop Jarvis") { stopService(Intent(this, JarvisService::class.java)) }
        setContentView(col)
    }
}
