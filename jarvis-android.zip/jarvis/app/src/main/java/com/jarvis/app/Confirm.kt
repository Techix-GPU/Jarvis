package com.jarvis.app

/** Voice confirmation before anything is sent. Default is "no" if the service isn't running. */
object Confirm {
    @Volatile var handler: ((String) -> Boolean)? = null

    /** Blocks (call from a background thread). True only if the user says yes. */
    fun ask(prompt: String): Boolean = handler?.invoke(prompt) ?: false

    fun isYes(text: String): Boolean {
        val w = text.lowercase().split(" ", ",", ".")
        if (w.any { it in setOf("no", "nope", "cancel", "stop", "don't", "dont", "wait") }) return false
        return w.any { it in setOf("yes", "yeah", "yep", "yup", "confirm", "sure", "okay", "ok", "proceed") } ||
            text.lowercase().contains("go ahead") || text.lowercase().contains("send it") ||
            text.lowercase().contains("do it")
    }
}
