package com.jarvis.app

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/** Online voice. Returns an mp3 file, or null so the caller falls back to the phone's own voice. */
object ElevenLabs {
    private val http = OkHttpClient.Builder().callTimeout(20, TimeUnit.SECONDS).build()
    private const val DEFAULT_MALE_VOICE = "pNInz6obpgDQGcFmaJgB" // "Adam", an ElevenLabs premade male voice

    fun fetch(ctx: Context, text: String): File? {
        val p = ctx.getSharedPreferences("j", 0)
        val key = p.getString("eleven", "").orEmpty()
        if (key.isBlank()) return null
        val voice = p.getString("voice", "").orEmpty().ifBlank { DEFAULT_MALE_VOICE }
        val body = JSONObject().put("text", text).put("model_id", "eleven_flash_v2_5").toString()
        val req = Request.Builder()
            .url("https://api.elevenlabs.io/v1/text-to-speech/$voice?output_format=mp3_44100_64")
            .header("xi-api-key", key)
            .post(body.toRequestBody("application/json".toMediaType())).build()
        return try {
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) null else {
                    val f = File.createTempFile("tts", ".mp3", ctx.cacheDir)
                    f.outputStream().use { o -> r.body!!.byteStream().copyTo(o) }
                    f
                }
            }
        } catch (e: Exception) { null }
    }
}
