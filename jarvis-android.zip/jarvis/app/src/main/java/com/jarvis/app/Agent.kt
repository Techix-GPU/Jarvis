package com.jarvis.app

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.provider.AlarmClock
import org.json.JSONObject

class Agent(private val ctx: Context) {

    /** Runs a spoken command: custom commands first, then the built-in phone commands. No AI service is used. */
    fun run(command: String): String {
        Custom.handle(ctx, this, command)?.let { return it }
        return Offline(ctx, this).run(command)
    }

    private fun launch(i: Intent): String {
        val svc = JarvisAccessibility.instance ?: return "Accessibility service is not enabled"
        svc.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); Thread.sleep(1500); return "ok"
    }

    private val sendWords = setOf("send", "post", "reply", "publish", "tweet", "submit")

    /** Anything that sends a comment or message needs a spoken yes first. */
    private fun gate(acc: JarvisAccessibility, text: String): Boolean {
        val t = text.lowercase().trim()
        val typed = acc.inputText().trim()
        val sending = t in sendWords || t.startsWith("send") || (t == "comment" && typed.isNotBlank())
        if (!sending) return true
        val prompt = if (typed.isBlank()) "I'm about to tap $text. Say yes to confirm."
            else "I'm about to tap $text with this text: ${typed.take(150)}. Say yes to confirm."
        return Confirm.ask(prompt)
    }

    fun exec(name: String, a: JSONObject): String {
        val acc = JarvisAccessibility.instance ?: return "Accessibility service is not enabled"
        return try {
            when (name) {
                "open_app" -> {
                    val pm = ctx.packageManager
                    val q = a.getString("name").lowercase()
                    val apps = pm.queryIntentActivities(
                        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                    val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
                        ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
                    val i = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
                    if (i == null) "No app named ${a.getString("name")}" else launch(i)
                }
                "read_screen" -> acc.dump()
                "tap" -> {
                    val t = a.getString("text")
                    if (!gate(acc, t)) "The user said no. Do not send it; tell them it was cancelled."
                    else if (acc.tap(t)) "tapped" else "not found"
                }
                "type_text" -> if (acc.type(a.getString("text"), a.optString("enter") == "true")) "typed" else "no input field"
                "scroll" -> if (acc.scroll(a.getString("direction") == "down")) "scrolled" else "nothing to scroll"
                "press" -> if (acc.press(a.getString("button"))) "pressed" else "failed"
                "call" -> launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + a.getString("number"))))
                "open_url" -> launch(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url"))))
                "call_contact" -> {
                    val n = Contacts.find(ctx, a.getString("name"))
                    if (n == null) "No contact matching ${a.getString("name")}"
                    else launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n))))
                }
                "set_alarm" -> launch(Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.getString("hour").toInt())
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.getString("minute").toInt())
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                "wait" -> { Thread.sleep((a.optString("seconds").toLongOrNull() ?: 1L).coerceIn(1, 10) * 1000); "waited" }
                else -> "unknown tool"
            }
        } catch (e: Exception) { "error: ${e.message}" }
    }
}

fun isOnline(ctx: Context): Boolean {
    val cm = ctx.getSystemService(ConnectivityManager::class.java)
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
}
