package com.jarvis.app

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/** Free on-device voice model (Vosk). Downloaded once by the app itself, no key needed. */
object VoskModel {
    private const val URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"

    fun dir(ctx: Context) = File(ctx.filesDir, "vosk")
    fun ready(ctx: Context) = File(dir(ctx), "am").exists()

    /** Returns null on success, or an error message. */
    fun download(ctx: Context): String? {
        return try {
            val http = OkHttpClient.Builder().readTimeout(120, TimeUnit.SECONDS).build()
            val tmp = File(ctx.filesDir, "vosk_tmp")
            tmp.deleteRecursively(); tmp.mkdirs()
            http.newCall(Request.Builder().url(URL).build()).execute().use { r ->
                if (!r.isSuccessful) return "Download failed (${r.code})"
                ZipInputStream(r.body!!.byteStream()).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val rel = e.name.substringAfter('/', "")
                        if (rel.isNotEmpty()) {
                            val out = File(tmp, rel)
                            if (!out.canonicalPath.startsWith(tmp.canonicalPath)) return "Bad file in model"
                            if (e.isDirectory) out.mkdirs()
                            else { out.parentFile?.mkdirs(); out.outputStream().use { o -> z.copyTo(o) } }
                        }
                        e = z.nextEntry
                    }
                }
            }
            dir(ctx).deleteRecursively()
            if (!tmp.renameTo(dir(ctx))) return "Couldn't save the model"
            null
        } catch (ex: Exception) { "Download failed: ${ex.message}" }
    }
}
