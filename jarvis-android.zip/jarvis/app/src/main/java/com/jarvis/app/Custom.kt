package com.jarvis.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Lets the user extend Jarvis by voice, with no rebuild:
 *  - "add a command: when I say good night, set an alarm for 7 and open YouTube"  (needs internet once; then works offline)
 *  - "from now on, keep answers very short" / "remember that ..."                 (standing instructions)
 *  - "list my commands", "forget command good night", "forget all notes"
 *  - "feature request: ..."  (saved; copy from the app and send to Claude for new code features)
 */
object Custom {
    private val ALLOWED = setOf("open_app", "open_url", "call_contact", "call", "set_alarm", "tap",
        "type_text", "scroll", "press", "wait")

    private val TEACH_SYSTEM = """Convert the user's description of a new voice command into JSON only (no markdown, no explanation):
{"trigger":"short phrase the user will say, lowercase, no punctuation","steps":[{"tool":"open_app","args":{"name":"YouTube"}}]}
Allowed tools and args: open_app{name}, open_url{url}, call_contact{name}, call{number}, set_alarm{hour,minute} (24h), tap{text}, type_text{text,enter}, scroll{direction}, press{button}, wait{seconds}.
All arg values are strings. Use the fewest steps. Never include a step that taps Send or Post."""

    private fun file(ctx: Context, n: String) = File(ctx.filesDir, n)
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("j", 0)

    private fun macros(ctx: Context): JSONArray =
        try { JSONArray(file(ctx, "macros.json").readText()) } catch (e: Exception) { JSONArray() }

    private fun save(ctx: Context, a: JSONArray) = file(ctx, "macros.json").writeText(a.toString())

    /** Standing instructions saved by voice. */
    fun noteBlock(ctx: Context): String {
        val n = prefs(ctx).getString("notes", "").orEmpty()
        return if (n.isBlank()) "" else "\nStanding instructions from the user:\n$n"
    }

    /** Returns a spoken reply if this was a custom/management command, else null. */
    fun handle(ctx: Context, agent: Agent, raw: String): String? {
        val c = raw.lowercase().trim().trimEnd('.', '?', '!')

        if (c in listOf("list my commands", "what commands do i have", "show my commands", "what can you do")) {
            val m = macros(ctx)
            if (m.length() == 0) return "You have no custom commands yet. Say add a command, then describe it."
            return "Your commands are: " + (0 until m.length()).joinToString(", ") { m.getJSONObject(it).getString("trigger") }
        }
        Regex("^(forget|delete|remove) (the )?(command|task|shortcut) (.+)$").find(c)?.let { mt ->
            val t = mt.groupValues[4].trim()
            val m = macros(ctx); val keep = JSONArray()
            for (i in 0 until m.length()) if (m.getJSONObject(i).getString("trigger") != t) keep.put(m.getJSONObject(i))
            if (keep.length() == m.length()) return "I don't have a command called $t."
            save(ctx, keep); return "Forgot $t."
        }
        if (c.startsWith("forget all notes") || c.startsWith("clear my notes")) {
            prefs(ctx).edit().remove("notes").apply(); return "Cleared your standing instructions."
        }
        if (c.startsWith("feature request") || c.startsWith("i want a new feature") || c.startsWith("add a feature")) {
            file(ctx, "requests.txt").appendText("- $raw\n")
            return "Saved. Open the Jarvis app and tap copy requests, then send them to Claude."
        }
        if (c.startsWith("from now on ") || c.startsWith("remember that ") || c.startsWith("remember to ")) {
            val old = prefs(ctx).getString("notes", "").orEmpty()
            prefs(ctx).edit().putString("notes", (old + "- $raw\n").takeLast(2000)).apply()
            return "Okay, I'll remember that."
        }
        if (Regex("^(teach|add|create|learn|make|new)( yourself)?( a| an| new)*\\s*(command|task|skill|shortcut|routine)")
                .containsMatchIn(c) || c.startsWith("when i say ")) return teach(ctx, agent, raw)

        // run a saved command
        val m = macros(ctx)
        for (i in 0 until m.length()) {
            val o = m.getJSONObject(i)
            val t = o.getString("trigger")
            if (t.length >= 3 && (c == t || c.contains(t))) return runMacro(agent, o)
        }
        return null
    }

    private fun teach(ctx: Context, agent: Agent, raw: String): String {
        return "Teaching new commands needs an AI service, which is turned off."
    }

    @Suppress("unused")
    private fun teachWithAi(ctx: Context, agent: Agent, raw: String, out: String): String {
        val o = try {
            JSONObject(out.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim())
        } catch (e: Exception) { return "I didn't understand that command." }
        val trigger = o.optString("trigger").lowercase().trim()
        val raws = o.optJSONArray("steps") ?: return "I didn't understand that command."
        if (trigger.length < 3 || raws.length() == 0) return "I didn't understand that command."

        val steps = JSONArray(); val spoken = mutableListOf<String>()
        for (i in 0 until raws.length()) {
            val s = raws.getJSONObject(i); val tool = s.getString("tool")
            if (tool !in ALLOWED) return "That needs something I can't do by voice yet."
            val a = JSONObject(); val src = s.optJSONObject("args") ?: JSONObject()
            src.keys().forEach { k -> a.put(k, src.get(k).toString()) }
            steps.put(JSONObject().put("tool", tool).put("args", a))
            spoken.add(tool.replace('_', ' ') + " " + a.keys().asSequence().joinToString(" ") { a.getString(it) })
        }
        if (!Confirm.ask("I'll learn this. When you say $trigger, I will ${spoken.joinToString(", then ")}. Say yes to save."))
            return "Okay, not saved."

        val old = macros(ctx); val all = JSONArray()
        for (i in 0 until old.length()) if (old.getJSONObject(i).getString("trigger") != trigger) all.put(old.getJSONObject(i))
        all.put(JSONObject().put("trigger", trigger).put("steps", steps))
        save(ctx, all)
        return "Learned. Say $trigger to use it."
    }

    private fun runMacro(agent: Agent, m: JSONObject): String {
        val steps = m.getJSONArray("steps")
        for (i in 0 until steps.length()) {
            val s = steps.getJSONObject(i)
            val r = agent.exec(s.getString("tool"), s.getJSONObject("args"))
            if (r.startsWith("The user said no")) return "Okay, cancelled."
            if (r == "Accessibility service is not enabled") return r
            Thread.sleep(700)
        }
        return "Done."
    }
}
