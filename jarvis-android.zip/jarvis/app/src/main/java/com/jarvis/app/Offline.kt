package com.jarvis.app

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.Uri
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Fixed voice commands run instantly; anything else becomes a Google search on this phone. */
class Offline(private val ctx: Context, private val agent: Agent) {

    private val ones = mapOf("zero" to 0, "oh" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5,
        "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12,
        "thirteen" to 13, "fourteen" to 14, "fifteen" to 15, "sixteen" to 16, "seventeen" to 17,
        "eighteen" to 18, "nineteen" to 19)
    private val tens = mapOf("twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50)

    private val name = ctx.getSharedPreferences("j", 0).getString("name", "Shiba")
        ?.ifBlank { "Shiba" } ?: "Shiba"

    private fun isNumberWord(w: String) = ones.containsKey(w) || w.all(Char::isDigit)

    private fun digits(s: String): String =
        s.split(" ").joinToString("") { (ones[it]?.takeIf { v -> v < 10 })?.toString() ?: it.filter(Char::isDigit) }

    private fun nums(tokens: List<String>): List<Int> {
        val out = mutableListOf<Int>()
        var i = 0
        while (i < tokens.size) {
            val t = tokens[i]
            when {
                t.toIntOrNull() != null -> out.add(t.toInt())
                tens.containsKey(t) -> {
                    var v = tens[t]!!
                    val n = ones[tokens.getOrNull(i + 1)]
                    if (n != null && n in 1..9) { v += n; i++ }
                    out.add(v)
                }
                ones.containsKey(t) -> out.add(ones[t]!!)
            }
            i++
        }
        return out
    }

    private fun alarm(c: String): String {
        val tokens = c.substringAfter("alarm").replace(":", " ").split(" ").filter { it.isNotBlank() }
        val n = nums(tokens)
        if (n.isEmpty()) return "Say the time, like set an alarm for seven thirty a m"
        var h = n[0]
        val rest = n.drop(1)
        val m = when { rest.isEmpty() -> 0; rest[0] == 0 && rest.size > 1 -> rest[1]; else -> rest[0] }
        val pm = Regex("\\bp\\.? ?m\\b|\\bpm\\b|evening|night|afternoon").containsMatchIn(c)
        val am = Regex("\\ba\\.? ?m\\b|\\bam\\b|morning").containsMatchIn(c)
        if (pm && h < 12) h += 12
        if (am && h == 12) h = 0
        if (h > 23 || m > 59) return "I didn't catch that time"
        agent.exec("set_alarm", JSONObject().put("hour", h.toString()).put("minute", m.toString()))
        return "Alarm set for %d:%02d".format(h, m)
    }

    private fun ok(r: String, good: String, bad: String) =
        if (r in listOf("ok", "tapped", "typed", "scrolled", "pressed", "waited")) good else bad

    fun run(cmd: String): String {
        val c = cmd.lowercase().trim().removePrefix("please ").trim()
        fun arg(vararg p: String) = p.firstOrNull { c.startsWith("$it ") }?.let { c.removePrefix(it).trim() }
        fun press(b: String, say: String) = ok(agent.exec("press", JSONObject().put("button", b)), say, "Couldn't do that")
        fun tapRaw(t: String) = agent.exec("tap", JSONObject().put("text", t))
        fun tap(t: String) = tapRaw(t) == "tapped"
        fun declined(r: String) = r.startsWith("The user said no")

        // small talk that uses the user's name
        if (c.contains("how are you") || c.contains("how's it going") || c.contains("how you doing"))
            return "I'm doing great. How is your day going?"
        if (c.contains("my day") || c.contains("my day's"))
            return if (listOf("good", "great", "fine", "nice", "amazing").any { c.contains(it) })
                "Glad to hear it." else "I'm sorry to hear that. I'm here if you need anything."
        if (c.contains("my name") || c.contains("who am i")) return "Your name is $name."
        if (c.startsWith("good morning")) return "Good morning."
        if (c.startsWith("good afternoon")) return "Good afternoon."
        if (c.startsWith("good evening") || c.startsWith("good night")) return "${c.split(" ").take(2).joinToString(" ").replaceFirstChar { it.uppercase() }}."
        if (c in listOf("hello", "hi", "hey", "hello jarvis", "hi jarvis")) return "Hey, how can I help?"
        if (c.startsWith("thank")) return "Anytime."

        // alarms
        if (c.contains("alarm") && (c.contains("set") || c.contains("wake me"))) return alarm(c)

        // system buttons
        if (c in listOf("go back", "back")) return press("back", "Going back")
        if (c in listOf("go home", "home", "home screen")) return press("home", "Going home")
        if (c in listOf("recent apps", "recents", "show recent apps")) return press("recents", "Showing recent apps")
        if (c.contains("notification")) return press("notifications", "Opening notifications")
        if (c.contains("quick settings")) return press("quick_settings", "Opening quick settings")

        // flashlight
        if (c.contains("flashlight") || c.contains("torch")) {
            val on = !c.contains(" off") && !c.startsWith("off")
            return try {
                val cm = ctx.getSystemService(CameraManager::class.java)
                cm.setTorchMode(cm.cameraIdList.first(), on)
                if (on) "Flashlight on" else "Flashlight off"
            } catch (e: Exception) { "Couldn't reach the flashlight" }
        }

        // local answers
        if (c.contains("what time")) return "It's " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        if (c.contains("what") && c.contains("date") || c.contains("what day")) {
            return "Today is " + SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
        }
        if (c.contains("read") && c.contains("screen") || c.contains("what's on") && c.contains("screen")) {
            return agent.exec("read_screen", JSONObject()).take(400)
        }

        // social: like / comment in whatever app is open
        if (c.startsWith("like") && (c.contains("post") || c.contains("this") || c.contains("it") ||
                c.contains("photo") || c.contains("video") || c.contains("reel"))) {
            return if (tap("Like")) "Liked" else "I couldn't find the like button"
        }
        if (c.startsWith("comment ")) {
            var t = c.removePrefix("comment ").trim()
            for (p in listOf("saying ", "that says ", "says ", "on this post ", "on this ")) t = t.removePrefix(p)
            if (!tap("Comment")) return "I couldn't find the comment button"
            Thread.sleep(1500)
            if (agent.exec("type_text", JSONObject().put("text", t).put("enter", "false")) != "typed") return "No comment box found"
            Thread.sleep(600)
            var r = tapRaw("Post")
            if (r == "not found") r = tapRaw("Send")
            return when {
                r == "tapped" -> "Commented"
                declined(r) -> "Okay, I did not post it"
                else -> "I typed it but couldn't find the post button"
            }
        }

        // YouTube search
        Regex("^(?:search )?(?:on )?youtube (?:for )?(.+)$").find(c)?.let {
            agent.exec("open_url", JSONObject().put("url", "https://www.youtube.com/results?search_query=" + Uri.encode(it.groupValues[1])))
            return "Searching YouTube for ${it.groupValues[1]}"
        }
        Regex("^(?:search|play) (.+) on youtube$").find(c)?.let {
            agent.exec("open_url", JSONObject().put("url", "https://www.youtube.com/results?search_query=" + Uri.encode(it.groupValues[1])))
            return "Searching YouTube for ${it.groupValues[1]}"
        }

        // screen control
        if (c == "scroll down" || c == "scroll up") {
            return ok(agent.exec("scroll", JSONObject().put("direction", c.removePrefix("scroll ").trim())), "Scrolled", "Nothing to scroll")
        }
        arg("tap", "click", "press", "select")?.let {
            val r = tapRaw(it)
            return when {
                r == "tapped" -> "Tapped $it"
                declined(r) -> "Okay, cancelled"
                else -> "I couldn't find $it on screen"
            }
        }
        arg("type", "write")?.let {
            return ok(agent.exec("type_text", JSONObject().put("text", it).put("enter", "false")), "Typed", "No text field found")
        }
        arg("search for", "search", "google")?.let {
            return googleSearch(it)
        }

        // calls: digits or a contact name
        arg("call", "dial", "phone")?.let { who ->
            val parts = who.split(" ")
            if (parts.all { isNumberWord(it) } && digits(who).length >= 3) {
                agent.exec("call", JSONObject().put("number", digits(who))); return "Calling ${digits(who)}"
            }
            val r = agent.exec("call_contact", JSONObject().put("name", who))
            return if (r == "ok") "Calling $who" else r
        }

        // any app
        arg("open", "launch", "start")?.let {
            val r = agent.exec("open_app", JSONObject().put("name", it))
            return if (r == "ok") "Opening $it" else r
        }

        // everything else, including general questions: search Google on this phone
        return googleSearch(cmd)
    }

    private fun googleSearch(q: String): String {
        val r = agent.exec("open_url", JSONObject().put("url", "https://www.google.com/search?q=" + Uri.encode(q)))
        return if (r == "ok") "Searching Google for $q" else r
    }
}
