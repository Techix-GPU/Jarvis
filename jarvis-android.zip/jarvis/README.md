# Jarvis for Android

Say "Jarvis", wait for the beep, then give a command. Jarvis runs fixed phone commands (open apps, call, alarms, tap, type, scroll, flashlight, YouTube search). Anything else is searched on Google on your phone. No AI key is needed.

## Keys
- Picovoice AccessKey (free, console.picovoice.ai): required, it listens for the wake word.
- ElevenLabs key: optional, for a nicer voice.

## First run (in the app, in order)
1. Grant permissions (allow the microphone).
2. Enable "Jarvis" under Accessibility (if restricted: App info > three dots > Allow restricted settings).
3. Allow display over other apps.
4. Paste your Picovoice key and tap Start Jarvis.

## Build without a computer
Use GitHub in your phone browser: upload jarvis-android.zip to a new repo, add build.yml as .github/workflows/build.yml, run it on the Actions tab, then download the jarvis-apk artifact.
